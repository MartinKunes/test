﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kviz
{
    internal class Vytvoreni
    {

        //načte soubor
        System.IO.StreamWriter file = new System.IO.StreamWriter("test1.txt", true);

        //vytvori otazky
        public void VytvoreniOtazky()
        {
            string[] otazka = new string[5];
            string[] odpoved1 = new string[5];
            string[] odpoved2 = new string[5];
            string[] odpoved3 = new string[5];
            string[] odpoved4 = new string[5];
            string[] spravna = new string[5];

            //cyklus na vytvoreni otazek
            for (int i = 0; i < 1; i++)
            {
                Console.WriteLine("Zadej otazku");
                otazka[i] = Console.ReadLine();
                Console.WriteLine("Zadej odpoved 1");
                odpoved1[i] = Console.ReadLine();
                Console.WriteLine("Zadej odpoved 2");
                odpoved2[i] = Console.ReadLine();
                Console.WriteLine("Zadej odpoved 3");
                odpoved3[i] = Console.ReadLine();
                Console.WriteLine("Zadej odpoved 4");
                odpoved4[i] = Console.ReadLine();
                Console.WriteLine("Zadej spravnu odpoved");
                spravna[i] = Console.ReadLine();
            }

            //vytvori string pro zapis do souboru a zapíše do něj
            string[] lines = new string[5];
            for (int i = 0; i < 1; i++)
            {
                file.WriteLine(lines[i] = otazka[i] + ";" + odpoved1[i] + ";" + odpoved2[i] + ";" + odpoved3[i] + ";" + odpoved4[i] + ";" + spravna[i]);
            }
            //zavre textovy soubor
            file.Close();
        }

    }
}
