﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kviz
{
    internal class Pokracovani
    {
        
        //na opakovani programu
        private bool hraBezi = true;

        public bool HraBezi
        {
            get { return hraBezi; }
            set { hraBezi = value; }
        }


    }
}
