﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Kviz
{
    internal class Otazky
    {
        //vytvorim pole pro otazky, odpovedi a spravou odpoved
        public string[] otazka = new string[5];
        public string[] odpoved1 = new string[5];
        public string[] odpoved2 = new string[5];
        public string[] odpoved3 = new string[5];
        public string[] odpoved4 = new string[5];
        public string[] spravna = new string[5];

        //nacte soubor, split rozdělí řádek na jednotlive otazky, odpovedi a uloží je do vlastního pole když mají mezi sebou ";" 
        public void NacteniOtazky()
        {
            string[] lines = System.IO.File.ReadAllLines("test1.txt");

            int i = 0;
            foreach (string line in lines)
            {
                string[] pole = line.Split(';');
                otazka[i] = pole[0];
                odpoved1[i] = pole[1];
                odpoved2[i] = pole[2];
                odpoved3[i] = pole[3];
                odpoved4[i] = pole[4];
                spravna[i] = pole[5];
                i++;
            }
        }

    }

    }















