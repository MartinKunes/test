﻿namespace Kviz
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //while cyklus pro opakovani programu, moznost 1 pro vytvareni otazky, moznost 2 pro hraní
            Pokracovani pokracovani = new Pokracovani();
            while (pokracovani.HraBezi == true)
            {
                Console.WriteLine("Zadej 1 pro vytvoreni otazky \n2 pro hraní");
                string volba = Console.ReadLine();
                if (volba == "1")
                {
                    Vytvoreni vytvor = new Vytvoreni();
                    vytvor.VytvoreniOtazky();
                }
                else if (volba == "2")
                {
                    Otazky otazky = new Otazky();
                    otazky.NacteniOtazky();

                    //spočítá počet řádků, aby mohl vypsat všechny otazky
                    int pocetOtazek = File.ReadLines("test1.txt").Count();
                    
                    int spravne = 0;
                    for (int i = 0; i < pocetOtazek; i++)
                    {
                        Console.WriteLine("----------\n"+otazky.otazka[i]);
                        Console.WriteLine("1: " + otazky.odpoved1[i]);
                        Console.WriteLine("2: " + otazky.odpoved2[i]);
                        Console.WriteLine("3: " + otazky.odpoved3[i]);
                        Console.WriteLine("4: " + otazky.odpoved4[i]);
                        Console.WriteLine("Zadej spravnou odpoved");
                        string odpoved = Console.ReadLine();
                        if (odpoved == otazky.spravna[i])
                        {
                            Console.WriteLine("----------\n Spravne");
                            spravne++;
                        }
                        else
                        {
                            Console.WriteLine("Spatne");
                        }
                    }
                    Console.WriteLine("Spravne odpovedi: " + spravne);
                }
                else
                {
                    //vypíše se, pokud se zadá špatná hodnota
                    Console.WriteLine("------\nZadejte spravnou hodnotu");
                }
            }
            
            









        }
    }
}